INSTALLATION INSTRUCTIONS

1 Download all the files and put them into a folder

2 go to chrome extension management and enable developer settings

3 Click load unpacked and select your folder

4 Test if it works by searching something with the words of either "low" "taper" "fade" or "massive"
